package com.sunbeaminfo.application1;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

public class MyService extends Service {


    void veryImportantTask() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.e("MyService", "going to sleep now :)");
                    Thread.sleep(10000);
                    Log.e("MyService", "coming out of sleep now :(");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e("MyService", "onCreate()");
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.e("MyService", "onBind()");
        veryImportantTask();
        return null;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.e("MyService", "onUnbind()");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("MyService", "onDestroy()");
    }
}
