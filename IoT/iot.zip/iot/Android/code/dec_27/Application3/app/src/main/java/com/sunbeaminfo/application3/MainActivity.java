package com.sunbeaminfo.application3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    float x = 0, y = 0, z = 0;

    // custom view
    class MyView extends View {

        public MyView(Context context) {
            super(context);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            // create the paint
            Paint paint = new Paint();
            paint.setColor(Color.RED);

            // draw a circle
            canvas.drawCircle(300 + (x * 10), 300 + (y * 10), 100, paint);

            // redraw
            invalidate();
        }
    }

    MyView myView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        myView = new MyView(this);

        // set the myView to the activity
        setContentView(myView);
    }


    @Override
    protected void onResume() {
        super.onResume();

        // to get the system (started) service
        SensorManager manager = (SensorManager) getSystemService(SENSOR_SERVICE);

        // select the sensor
        Sensor sensor = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        // give me all the changes in the sensor values
        manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onStop() {
        super.onStop();

        // to get the system (started) service
        SensorManager manager = (SensorManager) getSystemService(SENSOR_SERVICE);

        // stop getting the values
        manager.unregisterListener(listener);
    }


    SensorEventListener listener = new SensorEventListener() {

        @Override
        public void onSensorChanged(SensorEvent event) {
            float values[] = event.values;

            x = values[0];
            y = values[1];
            z = values[2];

            Log.e("MainActivity", "X: " + x + ", Y: " + y + ", Z: " + z);

        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };

}
