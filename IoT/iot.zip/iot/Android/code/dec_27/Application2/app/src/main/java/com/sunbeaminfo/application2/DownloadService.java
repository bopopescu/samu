package com.sunbeaminfo.application2;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

public class DownloadService extends Service {

    void downloadFile() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.e("DownloadService", "download started");
                    Thread.sleep(5000);
                    Log.e("DownloadService", "download finished");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e("DownloadService", "onCreate()");
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.e("DownloadService", "onBind()");
        downloadFile();
        return null;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.e("DownloadService", "onUnbind()");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("DownloadService", "onDestroy()");
    }
}
