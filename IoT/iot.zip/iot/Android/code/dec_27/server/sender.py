# import the notification service
from pyfcm import FCMNotification

# create an object of service
service = FCMNotification(api_key='AIzaSyCaD026HoxDtBjLhhJEEpoQHw2w7QhS_Yk')

# send the message
registration_id = 'd1RIOAqFCdo:APA91bGJQSC39Na0iAyvYX2q2oDXmZctRHakTfxYHtSkpTjhpJVkQa-_p29SdbqTIIS_UUOYwbJNVXfjwskYx6Kx2bI3JnTOE-YKthtvPg9pG4JN_rSfOUo-N2NeMedI8vXsAghD0WYG'
message_title = 'temperature changed'
message_body = '79'
service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
