package com.sunbeaminfo.application7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textMessage = findViewById(R.id.textMessage);

        // local broadcast receiver
        BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                Log.e("receiver", "message is received by local BR");
                textMessage.setText("Message received");
            }
        };


        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("com.sunbeaminfo.application7.MY_MESSAGE");

        // register the local broadcast receiver
        registerReceiver(receiver, intentFilter);
    }

    public void onSend(View v) {
        Log.e("MainActivity", "Sending Message");

        // create the message
        Intent message = new Intent();
        message.setAction("com.sunbeaminfo.application7.MY_MESSAGE");

        // send the message
        sendBroadcast(message);
    }
}
