package com.sunbeaminfo.application5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    // collection
    ArrayList<String> movies = new ArrayList<>();

    ListView listView;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        movies.add("Toy Story");
        movies.add("Cars");
        movies.add("Moana");
        movies.add("Storks");
        movies.add("Frozen");

        listView = findViewById(R.id.listView);

        // create an adapter for rendering the movie names from array into the listview
        adapter = new ArrayAdapter<>(this, R.layout.list_item_movie, movies);

        // use the adapter with ListView
        listView.setAdapter(adapter);

    }
}
