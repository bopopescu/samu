package com.sunbeaminfo.application4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class InputActivity extends AppCompatActivity {

    EditText editName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        editName = findViewById(R.id.editName);
    }

    public void onSave(View v) {
        String name = editName.getText().toString();

        Intent intent = new Intent();
        intent.putExtra("name", name);

        setResult(0, intent);

        finish();
    }

    public void onCancel(View v) {
        finish();
    }
}
