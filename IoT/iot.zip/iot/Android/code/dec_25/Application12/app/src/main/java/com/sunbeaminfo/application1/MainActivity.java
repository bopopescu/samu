package com.sunbeaminfo.application1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonLaunch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonLaunch = findViewById(R.id.buttonLaunch);
        buttonLaunch.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == buttonLaunch) {
            // src: MainActivitiy
            // cmp: ResultActivity
            Intent intent = new Intent(this, ResultActivity.class);

            // intention
            startActivity(intent);
        }
    }
}
