package com.sunbeaminfo.application6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    TextView textCar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        textCar = findViewById(R.id.textCar);

        Intent intent = getIntent();
        String car = intent.getStringExtra("car");
        textCar.setText("Selected car: " + car);
    }

    public void goBack(View v) {
        finish();
    }
}
