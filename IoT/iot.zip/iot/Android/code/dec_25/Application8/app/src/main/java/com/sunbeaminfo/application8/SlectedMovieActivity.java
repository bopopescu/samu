package com.sunbeaminfo.application8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SlectedMovieActivity extends AppCompatActivity {

    TextView textMovie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slected_movie);

        textMovie = findViewById(R.id.textMovie);

        Intent intent = getIntent();
        String movie = intent.getStringExtra("movie");
        textMovie.setText("Selected Movie: " + movie);
    }

    public void onBack(View v) {
        finish();
    }
}
