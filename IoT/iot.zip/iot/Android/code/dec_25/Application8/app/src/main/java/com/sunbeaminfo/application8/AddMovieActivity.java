package com.sunbeaminfo.application8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class AddMovieActivity extends AppCompatActivity {

    EditText editTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_movie);

        editTitle = findViewById(R.id.editTitle);
    }

    public void onAdd(View v) {
        String title = editTitle.getText().toString();
        Intent intent = new Intent();
        intent.putExtra("title", title);
        setResult(0, intent);
        finish();
    }

    public void onCancel(View v) {
        finish();
    }
}
