package com.sunbeaminfo.application8;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    ListView listView;
    ArrayAdapter<String> adapter;
    ArrayList<String> movies = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        movies.add("Leap");
        movies.add("Lucy");

        listView = findViewById(R.id.listView);
        adapter = new ArrayAdapter<>(this, R.layout.list_item_movie, movies);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String selectedMovie = movies.get(position);
        Toast.makeText(this, "Selected movie: " + selectedMovie, Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, SlectedMovieActivity.class);
        intent.putExtra("movie", selectedMovie);
        startActivity(intent);
    }

    public void onAddMovie(View v) {
        Intent intent = new Intent(this, AddMovieActivity.class);
        startActivityForResult(intent, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (data != null) {
            String title = data.getStringExtra("title");

            // add the data to the data source
            movies.add(title);

            // refresh the list view
            adapter.notifyDataSetChanged();
        }
    }
}
