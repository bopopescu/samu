package com.sunbeaminfo.application2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonBack;
    TextView textName, textAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        buttonBack = findViewById(R.id.buttonBack);
        buttonBack.setOnClickListener(this);

        textName = findViewById(R.id.textName);
        textAddress = findViewById(R.id.textAddress);

        // get the intent given by ActivityManager
        Intent intent = getIntent();

        String name = intent.getStringExtra("name");
        Log.e("ResultActivity", "name: " + name);
        textName.setText("Name: " + name);

        String address = intent.getStringExtra("address");
        textAddress.setText("Address: " + address);
    }

    @Override
    public void onClick(View v) {
        if (v == buttonBack) {
            finish();
        }
    }
}
