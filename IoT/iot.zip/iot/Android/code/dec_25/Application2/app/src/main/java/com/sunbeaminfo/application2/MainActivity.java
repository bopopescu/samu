package com.sunbeaminfo.application2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonSend;
    EditText editName, editAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editName = findViewById(R.id.editName);
        editAddress = findViewById(R.id.editAddress);

        buttonSend = findViewById(R.id.buttonSend);
        buttonSend.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if (v == buttonSend) {
            String name = editName.getText().toString();
            String address = editAddress.getText().toString();

            // launch the result activity
            Intent intent = new Intent(this, ResultActivity.class);

            intent.putExtra("name", name);
            intent.putExtra("address", address);

            startActivity(intent);

        }

    }
}
