package com.sunbeaminfo.application3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Log.e("SecondActivity", "onCreate()");
    }


    @Override
    protected void onStart() {
        super.onStart();
        Log.e("SecondActivity", "onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("SecondActivity", "onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("SecondActivity", "onPause()");
    }


    @Override
    protected void onStop() {
        super.onStop();
        Log.e("SecondActivity", "onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("SecondActivity", "onDestroy()");
    }

    public void goBack(View v) {
        finish();
    }
}
