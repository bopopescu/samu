package com.sunbeaminfo.application5;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences preferences =
                PreferenceManager.getDefaultSharedPreferences(this);

        String name = preferences.getString("name", "");

        textWelcome = findViewById(R.id.textWelcome);
        textWelcome.setText("Welcome user, " + name);
    }

    public void onLogout() {
        SharedPreferences preferences =
                PreferenceManager.getDefaultSharedPreferences(this);
        preferences
            .edit()
            .putBoolean("isLoggedIn", false)
            .commit();

        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);

        finish();
    }

    // for options menu


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Logout");
        menu.add("Close");
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getTitle().equals("Close")) {
            finish();
        } else if (item.getTitle().equals("Logout")) {

            // confirmation popup
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("confirmation");
            builder.setMessage("Are you sure you want to logout?");

            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    onLogout();
                }
            });

            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });

            builder.show();

        }
        return super.onOptionsItemSelected(item);
    }
}
