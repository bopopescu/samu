package com.sunbeaminfo.application5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText editEmail, editPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editEmail = findViewById(R.id.editEmail);
        editPassword = findViewById(R.id.editPassword);
    }

    public void onLogin(View v) {
        String email = editEmail.getText().toString();
        String password = editPassword.getText().toString();

        if (email.length() == 0) {
            editEmail.setError("email is mandatory");
        } else if (password.length() == 0) {
            editPassword.setError("password is mandatory");
        } else {

            // select * from user where email = 'user1@test.com' and password = 'user1'
            // if user exists, query returns valid information about the user
            // if use does not exist, query returns empty cursor

            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getReadableDatabase();

            String columns[] = {"id", "userName", "email", "phone"};
            String selection = "email = '" + email + "' and password = '" + password + "'";
            Cursor cursor = db.query("user", columns, selection, null, null, null, null);

            boolean isSuccessfulLogin = false;

            if (cursor.isAfterLast()) {
                // cursor is empty
                // user does not exist
                Toast.makeText(this, "Invalid user email or password", Toast.LENGTH_SHORT).show();
                isSuccessfulLogin = false;
            } else {
                // cursor is not empty
                // user exists

                cursor.moveToFirst();

                int userId = cursor.getInt(0); // id
                String userName = cursor.getString(1); // name
                String userEmail = cursor.getString(2); // email
                String userPhone = cursor.getString(3); // phone


                // user has logged in
                SharedPreferences preferences =
                        PreferenceManager.getDefaultSharedPreferences(this);
                preferences
                    .edit()
                    .putString("name", userName)
                    .putBoolean("isLoggedIn", true)
                    .commit();

                Toast.makeText(this, "Successful Login.. welcome " + userName, Toast.LENGTH_SHORT).show();
                isSuccessfulLogin = true;
            }

            cursor.close();
            db.close();

            if (isSuccessfulLogin) {
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }
    }

    public void onRegister(View v) {
        Intent intent = new Intent(this, RegistrationActivity.class);
        startActivity(intent);
    }
}
