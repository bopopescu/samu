package com.sunbeaminfo.application1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText editName;
    ListView listView;

    ArrayList<String> countries = new ArrayList<>();
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editName = findViewById(R.id.editName);

        listView = findViewById(R.id.listView);
        adapter = new ArrayAdapter<>(this, R.layout.list_item_country, countries);
        listView.setAdapter(adapter);
    }

    public void onSave(View v) {
        String name = editName.getText().toString();
        Log.e("MainActivity", "name: " + name);

        // collection of column name (key) and value pairs
        ContentValues values = new ContentValues();

        // add the column name and input pair
        values.put("countryName", name);


        // get the DBHelper object
        DBHelper helper = new DBHelper(this);

        // get the sqlite database object
        SQLiteDatabase db = helper.getWritableDatabase();

        // perform the operation
        db.insert("countries", null, values);		//table

        // close the db connection
        db.close();
    }

    public void onGet(View v) {

        // flush all the values from countries
        countries.clear();

        // get an object of DBHelper
        DBHelper helper = new DBHelper(this);

        // get SQLiteDatabase
        SQLiteDatabase db = helper.getReadableDatabase();

        // perform the operation
        // select countryName from countries;

        String columns[] = { "countryName" };
        Cursor cursor = db.query("countries", columns, null, null, null, null, null);

        // check if cursor has got any rows
        if (!cursor.isAfterLast()) {

            // get the data

            // as the cursor is pointing to the last record
            cursor.moveToFirst();


            while(!cursor.isAfterLast()) {
                // read the country name
                String name = cursor.getString(0);

                // Log.e("MainActivity", "name: " + name);

                countries.add(name);

                cursor.moveToNext();
            }

        }

        // close the cursor
        cursor.close();

        // close the connection
        db.close();


        // Log.e("MainActivity", "" + countries);

        // refresh the listView
        adapter.notifyDataSetChanged();
    }
}
