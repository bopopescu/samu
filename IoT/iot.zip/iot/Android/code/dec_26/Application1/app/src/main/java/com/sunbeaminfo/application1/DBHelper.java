package com.sunbeaminfo.application1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {


    // context
    // name   : file name of the database
    // factory: null
    // version: database version (by default = 1)
    public DBHelper(@Nullable Context context) {
        super(context, "app_db.sqlite", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // the db here is newly created empty db
        // initialize the schema (tables)
        // create a table with name countries and column countryName (text: string)
        db.execSQL("create table countries (countryName text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
