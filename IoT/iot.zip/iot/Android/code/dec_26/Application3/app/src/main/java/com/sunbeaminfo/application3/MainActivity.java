package com.sunbeaminfo.application3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    String leds[] = { "Red", "Green", "Blue" };
    Spinner spinner;

    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = findViewById(R.id.spinner);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, leds);
        spinner.setAdapter(adapter);
    }

    public void onSelect(View v) {
        int position = spinner.getSelectedItemPosition();
        String led = leds[position];
        Toast.makeText(this, "selected LED: " + led, Toast.LENGTH_SHORT).show();
    }
}
