package com.sunbeaminfo.application2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editName, editAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editName = findViewById(R.id.editName);
        editAddress = findViewById(R.id.editAddress);
    }

    public void onSave(View v) {
        String name = editName.getText().toString();
        String address = editAddress.getText().toString();

        SharedPreferences preferences =
                    PreferenceManager.getDefaultSharedPreferences(this);

//        SharedPreferences.Editor editor = preferences.edit();
//        editor.putString("name", name);
//        editor.putString("address", address);
//        editor.commit();

        preferences
            .edit()
            .putString("name", name)
            .putString("address", address)
            .commit();
    }

    public void onGet(View v) {
        SharedPreferences preferences =
                    PreferenceManager.getDefaultSharedPreferences(this);

        String name = preferences.getString("name", "");
        String address = preferences.getString("address", "");

        Toast.makeText(this, "name: " + name + ", address: " + address, Toast.LENGTH_SHORT).show();
    }
}
