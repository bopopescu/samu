from flask import Flask, jsonify, request
import mysql.connector

app = Flask(__name__)


@app.route('/', methods=["GET"])
def root():
    return 'Welcome to my APIs'


@app.route('/user', methods=["GET"])
def get_users():
    connection = mysql.connector.connect(host='localhost', user='root', password='root', database='desd_2019_aug', port=3306)
    statement = 'select id, firstName, lastName, email from user'
    cursor = connection.cursor()
    cursor.execute(statement)
    result = cursor.fetchall()
    cursor.close()
    connection.close()

    users = []
    for (id, firstName, lastName, email) in result:
        user = {
            "id": id,
            "firstName": firstName,
            "lastName": lastName,
            "email": email
        }
        users.append(user)

    return jsonify(users)


@app.route('/user/register', methods=["POST"])
def register_user():
    first_name = request.json.get('firstName')
    last_name = request.json.get('lastName')
    email = request.json.get('email')
    password = request.json.get('password')

    connection = mysql.connector.connect(host='localhost', user='root', password='root', database='desd_2019_aug',
                                         port=3306)
    statement = f"insert into user (firstName, lastName, email, password) values ('{first_name}', '{last_name}', '{email}', '{password}')"
    cursor = connection.cursor()
    cursor.execute(statement)
    cursor.close()
    connection.commit()
    connection.close()

    result = {"status": "success"}
    return jsonify(result)


@app.route('/user/login', methods=["POST"])
def user_login():
    email = request.json.get('email')
    password = request.json.get('password')

    connection = mysql.connector.connect(host='localhost', user='root', password='root', database='desd_2019_aug',
                                         port=3306)
    statement = f"select id, firstName, lastName, email from user where email = '{email}' and password = '{password}'"
    cursor = connection.cursor()
    cursor.execute(statement)
    result = cursor.fetchall()
    cursor.close()
    connection.commit()
    connection.close()

    user_status = ""
    if len(result) == 0:
        # user does not exist
        user_status = "error"
    else:
        # user exist
        user_status = "success"

    response = {
        "status": user_status
    }

    return jsonify(response)


@app.route('/product', methods=["GET"])
def get_products():
    connection = mysql.connector.connect(host='localhost', user='root', password='root', database='desd_2019_aug',
                                         port=3306)
    statement = 'select id, title, description, price from product'
    cursor = connection.cursor()
    cursor.execute(statement)
    result = cursor.fetchall()
    cursor.close()
    connection.close()

    products = []
    for (id, title, description, price) in result:
        product = {
            "id": id,
            "title": title,
            "description": description,
            "price": price
        }
        products.append(product)

    return jsonify(products)


app.run(host='0.0.0.0', port=4000, debug=True)