package com.sunbeaminfo.application1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Product> products = new ArrayList<>();
    ArrayAdapter<Product> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, products);
        listView.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadProducts();
    }

    private void loadProducts() {
        // clear the products list
        products.clear();

        // create url
        String url = "http://172.18.6.165:4000/product";

        // call api
        Ion.with(this)
            .load("GET", url)
            .asJsonArray()
            .setCallback(new FutureCallback<JsonArray>() {
                @Override
                public void onCompleted(Exception e, JsonArray result) {
                    Log.e("MainActivity", result.toString());

                    for (int index = 0; index < result.size(); index++) {

                        // get json object at every index
                        JsonObject object = result.get(index).getAsJsonObject();

                        // create an object of product
                        Product product = new Product();

                        // set the properties
                        product.setId(object.get("id").getAsInt());
                        product.setTitle(object.get("title").getAsString());
                        product.setDescription(object.get("description").getAsString());
                        product.setPrice(object.get("price").getAsFloat());


                        // add the product to the products list
                        products.add(product);
                    }

                    // refresh the list
                    adapter.notifyDataSetChanged();
                }
            });
    }

    // add options menu


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Refresh");
        menu.add("Close");
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getTitle().equals("Refresh")) {
            loadProducts();
        } else if (item.getTitle().equals("Close")) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
