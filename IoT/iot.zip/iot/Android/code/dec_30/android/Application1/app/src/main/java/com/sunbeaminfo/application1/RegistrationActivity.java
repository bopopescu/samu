package com.sunbeaminfo.application1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;


public class RegistrationActivity extends AppCompatActivity {

    EditText editEmail, editPassword, editFirstName, editLastName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        editEmail = findViewById(R.id.editEmail);
        editPassword = findViewById(R.id.editPassword);
        editFirstName = findViewById(R.id.editFirstName);
        editLastName = findViewById(R.id.editLastName);
    }

    public void onRegister(View v) {
        String email = editEmail.getText().toString();
        String password = editPassword.getText().toString();
        String firstName = editFirstName.getText().toString();
        String lastName = editLastName.getText().toString();

        if (email.length() == 0) {
            editEmail.setError("email is mandatory");
        } else if (password.length() == 0) {
            editPassword.setError("password is mandatory");
        } else {

            // create url
            String url = "http://172.18.6.165:4000/user/register";

            // create body
            JsonObject body = new JsonObject();
            body.addProperty("email", email);
            body.addProperty("password", password);
            body.addProperty("firstName", firstName);
            body.addProperty("lastName", lastName);

            // call API
            Ion.with(this)
                .load("POST", url)
                .setJsonObjectBody(body)
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        String status = result.get("status").getAsString();
                        if (status.equals("success")) {
                            Toast.makeText(RegistrationActivity.this, "Successfully register new account. Please login.", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(RegistrationActivity.this, "Error while registering account. Please try again.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

        }
    }

    public void onCancel(View v) {
        finish();
    }
}
