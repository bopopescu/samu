package com.sunbeaminfo.application1;

import androidx.annotation.NonNull;

public class Product {
    int id;
    String title;
    String description;
    float price;

    @NonNull
    @Override
    public String toString() {
        return "Id: " + id + ",\nTitle: " + title + ",\nDescription: " + description + ",\nPrice: " + price + "Rs";
    }

    public Product() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
}
