package com.sunbeaminfo.application2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText editUrl;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editUrl = findViewById(R.id.editUrl);
        imageView = findViewById(R.id.imageView);
    }

    public void onBrowse(View v) {
        // implicit intent
//        String url = "https://google.com";
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(editUrl.getText().toString()));
        startActivity(intent);
    }

    public void onDial(View v) {
        String phone = "tel://+9123434343";
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_DIAL);

        intent.setData(Uri.parse(phone));
        startActivity(intent);
    }

    public void onMakeCall(View v) {
        String phone = "tel://+9123434343";
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_CALL);

        intent.setData(Uri.parse(phone));
        startActivity(intent);
    }

    public void onAcceptCommand(View v) {
        Intent intent = new Intent();
        intent.setAction(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "What is your next command ?");
        startActivityForResult(intent, 1);
    }

    public void onTakePhoto(View v) {
        Intent intent = new Intent();
        intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, 0);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (data != null) {

            if (requestCode == 0) {
                // photo
                Bundle extras = data.getExtras();
                Bitmap bitmap = (Bitmap) extras.get("data");
                imageView.setImageBitmap(bitmap);
            } else if (requestCode == 1) {
                // for voice command
                ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                for (String result : results) {
                    Log.e("MainActivity", result);
                }
            }

        }
    }
}
