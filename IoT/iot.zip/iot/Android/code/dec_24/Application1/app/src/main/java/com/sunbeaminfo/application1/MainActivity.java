package com.sunbeaminfo.application1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // LinearLayout (container)
        LinearLayout layout = new LinearLayout(this);

        // change the orientation
        layout.setOrientation(LinearLayout.VERTICAL);


        // add label for name
        TextView textView = new TextView(this);
        textView.setText("Name");
        textView.setTextSize(20);

        // add the textView (Name) in the linear layout (container)
        layout.addView(textView);

        // add label for Address
        TextView textAddress = new TextView(this);
        textAddress.setText("Address");
        textAddress.setTextSize(20);

        // add the textAddress in the linear layout (container)
        layout.addView(textAddress);


        // add label for Phone
        TextView textPhone = new TextView(this);
        textPhone.setText("Phone Number");
        textPhone.setTextSize(20);

        // add the textPhone to the layout
        layout.addView(textPhone);

        // add the container inside the activity ui
        setContentView(layout);
    }
}
