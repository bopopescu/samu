package com.sunbeaminfo.application3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.DataOutput;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonDisplay, buttonClose;
    TextView textName, textAddress, textPhone, textResult;
    EditText editName, editAddress, editPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // create container
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        // name
        textName = new TextView(this);
        textName.setText("Name");
        textName.setTextSize(20);
        layout.addView(textName);

        editName = new EditText(this);
        layout.addView(editName);

        // address
        textAddress = new TextView(this);
        textAddress.setText("Address");
        textAddress.setTextSize(20);
        layout.addView(textAddress);

        editAddress = new EditText(this);
        layout.addView(editAddress);


        // phone
        textPhone = new TextView(this);
        textPhone.setText("Phone");
        textPhone.setTextSize(20);
        layout.addView(textPhone);

        editPhone = new EditText(this);
        layout.addView(editPhone);


        // create a container for buttons
        LinearLayout layoutButtons = new LinearLayout(this);
        layoutButtons.setOrientation(LinearLayout.HORIZONTAL);

        // Button for displaying the data
        buttonDisplay = new Button(this);
        buttonDisplay.setText("Display");
        buttonDisplay.setOnClickListener(this);
        layoutButtons.addView(buttonDisplay);


        // Button for closing the activity
        buttonClose = new Button(this);
        buttonClose.setText("Close");
        buttonClose.setOnClickListener(this);
        layoutButtons.addView(buttonClose);

        // add the buttons' container to the main layout
        layout.addView(layoutButtons);


        // used for displaying the result
        textResult = new TextView(this);
        textResult.setTextSize(30);
        textResult.setText("result will appear soon..");
        layout.addView(textResult);

        setContentView(layout);
    }

    @Override
    public void onClick(View v) {
        // v: verbose
        // d: debug
        // i: information
        // w: warning
        // e: error
        // assert

        if (v == buttonDisplay) {
            Log.e("MainActivity", "display button clicked");

            String name = editName.getText().toString();
            String address = editAddress.getText().toString();
            String phone = editPhone.getText().toString();

            // check if user has entered the name or address or phone
            if (name.length() == 0) {
                Log.e("MainAcitivity", "enter name");
                editName.setError("enter name");
                Toast.makeText(this, "enter name", Toast.LENGTH_SHORT).show();
            } else if (address.length() == 0) {
                Log.e("MainAcitivity", "enter address");
                editAddress.setError("enter address");
            } else if (phone.length() == 0) {
                Log.e("MainAcitivity", "enter phone");
                editPhone.setError("enter phone");
            } else {
                Log.e("MainActivity", "Name: " + name);
                Log.e("MainActivity", "Address: " + address);
                Log.e("MainActivity", "Phone: " + phone);

                String result = "Name: " + name + ", \nAddress: " + address + ", \nPhone: " + phone;
                textResult.setText(result);

                Toast.makeText(this, result, Toast.LENGTH_SHORT).show();
            }

        } else if (v == buttonClose) {
            Log.e("MainActivity", "close button clicked");

            // close the current activity
            finish();
        }
    }
}
