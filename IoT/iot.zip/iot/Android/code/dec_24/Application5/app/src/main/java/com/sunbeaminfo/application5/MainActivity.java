package com.sunbeaminfo.application5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText editName, editAddress, editCity, editState, editPincode, editPhone;
    Button buttonDisplay, buttonClose;
    TextView textResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editName = findViewById(R.id.editName);
        editAddress = findViewById(R.id.editAddress);
        editCity = findViewById(R.id.editCity);
        editState = findViewById(R.id.editState);
        editPincode = findViewById(R.id.editPincode);
        editPhone = findViewById(R.id.editPhone);

        textResult = findViewById(R.id.textResult);

        buttonDisplay = findViewById(R.id.buttonDisplay);
        buttonDisplay.setOnClickListener(this);

        buttonClose = findViewById(R.id.buttonClose);
        buttonClose.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == buttonDisplay) {

            String name = editName.getText().toString();
            String address = editAddress.getText().toString();
            String city = editCity.getText().toString();
            String state = editState.getText().toString();
            String pincode = editPincode.getText().toString();
            String phone = editPhone.getText().toString();

            if (name.length() == 0) {
                editName.setError("Please enter name");
            } else if (address.length() == 0) {
                editAddress.setError("Please enter address");
            } else {

                String result = "Name: " + name + ", \nAddress: " + address + ", \nCity: " + city + ", \nState: " + state + ", \nPincode: " + pincode + ", \nPhone: " + phone;
                textResult.setText(result);

                Toast.makeText(this, result, Toast.LENGTH_SHORT).show();
            }

        } else if (v == buttonClose) {
            finish();
        }
    }
}
