package com.sunbeaminfo.application4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText editName, editAddress, editPhone;
    Button buttonDisplay, buttonClose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // LayoutInflater: which inflates the xml file
        // - read the xml file
        // - create object for every element in the xml file
        //   - <LinearLayout .....> will create an object of LinearLayout class
        //   - <TextView ...> will create an object of TextView class
        // - build the hierarchy
        //   - object of TextView will be added into the object of LinearLayout
        //   - object of EditText will be added into the object of LinearLayout
        // - return the root element object (LinearLayout) which contains all the
        //   child element (TextView/EditText/Button) objects
        setContentView(R.layout.activity_main);


        editName = findViewById(R.id.editName);
        editAddress = findViewById(R.id.editAddress);
        editPhone = findViewById(R.id.editPhone);

        buttonDisplay = findViewById(R.id.buttonDisplay);
        buttonDisplay.setOnClickListener(this);

        buttonClose = findViewById(R.id.buttonClose);
        buttonClose.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == buttonDisplay) {
            String name = editName.getText().toString();
            String address = editAddress.getText().toString();
            String phone = editPhone.getText().toString();

            Log.e("MainActivity", "Name: " + name);
            Log.e("MainActivity", "Address: " + address);
            Log.e("MainActivity", "Phone number: " + phone);
        } else if (v == buttonClose) {
            finish();
        }
    }
}
