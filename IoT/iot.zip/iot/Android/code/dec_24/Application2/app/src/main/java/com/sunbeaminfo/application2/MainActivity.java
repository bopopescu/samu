package com.sunbeaminfo.application2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // container for holding all the edit texts
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);


        // get the input
        EditText editName = new EditText(this);
//        editName.setHint("Enter your name");
        layout.addView(editName);

        // get the address
        EditText editAddress = new EditText(this);
        layout.addView(editAddress);

        // get the phone
        EditText editPhone = new EditText(this);
        layout.addView(editPhone);


        // add the container in the activity
        setContentView(layout);
    }
}
