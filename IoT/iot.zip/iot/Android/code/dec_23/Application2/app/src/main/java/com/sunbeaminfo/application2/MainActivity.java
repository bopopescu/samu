package com.sunbeaminfo.application2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // load the xml file from
        // res -> layout -> activity_main.xml

        setContentView(R.layout.activity_main);
    }
}
