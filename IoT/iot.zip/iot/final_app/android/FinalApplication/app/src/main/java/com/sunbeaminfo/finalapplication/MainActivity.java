package com.sunbeaminfo.finalapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import android.widget.Switch;

import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {

    Switch switchRed, switchYellow, switchBulb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        switchRed = findViewById(R.id.switchRed);
        switchRed.setOnCheckedChangeListener(this);

        switchYellow = findViewById(R.id.switchYellow);
        switchYellow.setOnCheckedChangeListener(this);

        switchBulb = findViewById(R.id.switchBulb);
        switchBulb.setOnCheckedChangeListener(this);
    }

    public void onVoiceCommand(View v) {
        Intent intent = new Intent();
        intent.setAction(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Your command");
        startActivityForResult(intent, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results.size() > 0) {
                String result = results.get(0);
                Log.e("MainActivity", "command: " + result);
                if (result.contains("on")) {

                    if (result.contains("red")) {
                        switchRed.setChecked(true);
                        callAPI("red_led_on");
                    } else if (result.contains("yellow")) {
                        switchYellow.setChecked(true);
                        callAPI("yellow_led_on");
                    } else if (result.contains("bulb")) {
                        switchBulb.setChecked(true);
                        callAPI("bulb_on");
                    }
                } else if (result.contains("off") || result.contains("of")) {

                    if (result.contains("red")) {
                        switchRed.setChecked(false);
                        callAPI("red_led_off");
                    } else if (result.contains("yellow")) {
                        switchYellow.setChecked(false);
                        callAPI("yellow_led_off");
                    } else if (result.contains("bulb")) {
                        switchBulb.setChecked(false);
                        callAPI("bulb_off");
                    }
                }
            }
        }
    }

    private void callAPI(String path) {
        //  server url
        String url = "http://172.20.10.2/" + path;

        Log.e("MainActivity", "Calling REST API: " + url);

        // make the call
        Ion.with(this)
            .load(url)
            .asString()
            .setCallback(new FutureCallback<String>() {
                @Override
                public void onCompleted(Exception e, String result) {
                    Log.e("MainActivity", result);
                }
            });
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        String path = "";

        if (buttonView == switchRed) {

            // check if red LED switch is turned on
            if (switchRed.isChecked()) {
                path = "red_led_on";
            } else {
                path = "red_led_off";
            }
        } else if (buttonView == switchYellow) {

            // check if yellow LED switch is turned on
            if (switchYellow.isChecked()) {
                path = "yellow_led_on";
            } else {
                path = "yellow_led_off";
            }
        } else if (buttonView == switchBulb) {

            // check if bulb switch is turned on
            if (switchBulb.isChecked()) {
                path = "bulb_on";
            } else {
                path = "bulb_off";
            }
        }

        // call the api
        callAPI(path);
    }
}
