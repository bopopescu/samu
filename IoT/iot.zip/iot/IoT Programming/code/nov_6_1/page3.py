import sys

num = 10
print(f"size of num = {sys.getsizeof(num)}")
print(f"max int value = {sys.maxsize}")