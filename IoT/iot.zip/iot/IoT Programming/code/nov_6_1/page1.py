import os

print(f"name: {os.name}")
print(f"path: {os.path}")
print(f"envioron: {os.environ}")
print(f"SSH_SUNBEAM_MUM = {os.environ.get('SSH_SUNBEAM_MUM')}")

# os.system("ls -l ~/ ")

