from flask import Flask, request, jsonify

app = Flask(__name__)

temperature_values = []
proximity_values = []

@app.route("/", methods=["GET"])
def root():
    return "<h1>welcome to my application</h1>"


@app.route('/temp', methods=["GET"])
def get_temperature():
    # print(temperature_values)
    file = open('./temp.txt', 'r')

    temperatures = []
    data = file.readlines()
    file.close()

    for temp in data:
        temperatures.append({
            "temperature": int(temp.replace("\n", ""))
        })

    return jsonify(temperatures)


@app.route("/proximity", methods=["GET"])
def get_proximity():
    print(proximity_values)
    return "get proximity"


@app.route('/temp', methods=["POST"])
def post_temperature():
    temperature = request.json.get('temp')
    # print(f"temperature : {request.json.get('temp')}")
    temperature_values.append(temperature)

    file = open('./temp.txt', 'a')
    file.write(f"{temperature}\n")
    file.close()

    return "post temperature"


@app.route("/proximity", methods=["POST"])
def post_proximity():
    # print(f"received: {request.json}")
    # print(f"received proximity value: {request.json.get('value')}")
    proximity_values.append(request.json.get('value'))
    return "post proximity"


if __name__ == '__main__':
    app.run(debug=True)