import mysql.connector


def insert_temperature():
    # open the connection
    connection = mysql.connector.connect(host="localhost", user="root", password="root", database="desd_2019_aug")

    # create cursor
    cursor = connection.cursor()

    # query
    statement = "insert into temperatures (temperature_value) values (98)"

    # execute the query
    cursor.execute(statement)

    # commit the changes
    connection.commit()

    # close the connection
    cursor.close()
    connection.close()


# insert_temperature()


def get_temperatures():
    # connect to mysql
    connection = mysql.connector.connect(host="localhost", user="root", password="root", database="desd_2019_aug")

    # get the cursor
    cursor = connection.cursor()

    # query
    statement = "select * from temperatures;"

    # execute the statement
    cursor.execute(statement)

    # get the rows
    data = cursor.fetchall()

    # process the data
    # print(data)
    temperatures = []
    for temp in data:
        # print(f"id: {temp[0]}")
        # print(f"value: {temp[1]}")
        temperatures.append({
            "id": temp[0],
            "value": temp[1]
        })

    print(temperatures)

    # close the connection
    cursor.close()
    connection.close()


get_temperatures()




















