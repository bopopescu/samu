# val = input("enter number")
# print(f"val = {val}, type: {type(val)}")

num = int(input("enter number"))
print(f"num = {num}, type: {type(num)}")
