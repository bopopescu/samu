from flask import Flask, request
import mysql.connector

app = Flask(__name__)


@app.route("/", methods=["GET"])
def root():
    return "<h1>welcome to my backend</h1>"


@app.route("/temp", methods=["POST"])
def post_temperature():
    print("API called... ")
    temperature = request.json.get("temp")
    connection = mysql.connector.connect(host="localhost", user="root", password="root", database="desd_2019_aug")
    cursor = connection.cursor()
    statement = f"insert into temperatures (temperature_value) values ({temperature})"
    cursor.execute(statement)
    connection.commit()
    cursor.close()
    connection.close()

    return "inserted temperature"


if __name__ == '__main__':
    app.run(port=4000, host="0.0.0.0")
