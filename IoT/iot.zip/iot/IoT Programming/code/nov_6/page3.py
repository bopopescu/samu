# import only add function
# from page1 import add
# from page1 import multiply

from page1 import add, multiply

add(30, 50)
multiply(4, 6)