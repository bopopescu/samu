# import all the entities from page1
import page1

page1.add(40, 60)
page1.multiply(4, 6)

# add(40, 60)
# multiply(4, 7)

print(f"in page2: {__name__}")