import paho.mqtt.client as mqtt


# will be called when the machine gets connected to the broker
def on_connect(client, userdata, flags, rc):
    print("connected")

    # subscribe to the topic "temp"
    client.subscribe("temp")


# will be called when the client receives a message
def on_message(client, userdata, msg):
    print(f"message received: {msg.payload}")



client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message
client.connect("172.20.10.4", 1883, 60)
client.loop_forever()