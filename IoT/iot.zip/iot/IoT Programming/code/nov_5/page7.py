n1 = 10
n2 = 20

print(n1, n2)

# swap the values
n1, n2 = n2, n1

print(n1, n2)